-- Create the database
CREATE DATABASE BankDB;
USE BankDB;

-- Create Customers table
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Email VARCHAR(100),
    JoinDate DATE,
    Status VARCHAR(20) DEFAULT 'Active'
);

-- Create Accounts table
CREATE TABLE Accounts (
    AccountID INT PRIMARY KEY,
    CustomerID INT,
    AccountType VARCHAR(20),
    Balance DECIMAL(15, 2),
    OpenDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Create Transactions table
CREATE TABLE Transactions (
    TransactionID INT PRIMARY KEY,
    AccountID INT,
    Amount DECIMAL(15, 2),
    TransactionType VARCHAR(20),
    TransactionDate DATETIME,
    FOREIGN KEY (AccountID) REFERENCES Accounts(AccountID)
);

-- Create Loans table
CREATE TABLE Loans (
    LoanID INT PRIMARY KEY,
    CustomerID INT,
    Amount DECIMAL(15, 2),
    InterestRate DECIMAL(5, 2),
    StartDate DATE,
    EndDate DATE,
    Status VARCHAR(20),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Insert sample data into Customers
INSERT INTO Customers VALUES
(1, 'John', 'Doe', 'john.doe@email.com', '2020-01-15', 'Active'),
(2, 'Jane', 'Smith', 'jane.smith@email.com', '2020-03-22', 'Active'),
(3, 'Robert', 'Johnson', 'robert.j@email.com', '2021-05-10', 'Inactive'),
(4, 'Emily', 'Davis', 'emily.d@email.com', '2021-07-18', 'Active'),
(5, 'Michael', 'Brown', 'michael.b@email.com', '2022-02-05', 'Active');

-- Insert sample data into Accounts
INSERT INTO Accounts VALUES
(101, 1, 'Checking', 2500.00, '2020-01-15'),
(102, 1, 'Savings', 15000.00, '2020-01-15'),
(103, 2, 'Checking', 3500.00, '2020-03-22'),
(104, 3, 'Savings', 5000.00, '2021-05-10'),
(105, 4, 'Checking', 1200.00, '2021-07-18'),
(106, 5, 'Savings', 8000.00, '2022-02-05');

-- Insert sample data into Transactions
INSERT INTO Transactions VALUES
(1001, 101, 500.00, 'Deposit', '2023-01-10 09:15:00'),
(1002, 101, -200.00, 'Withdrawal', '2023-01-12 14:30:00'),
(1003, 102, 1000.00, 'Deposit', '2023-01-15 10:45:00'),
(1004, 103, -150.00, 'Withdrawal', '2023-01-18 16:20:00'),
(1005, 104, 300.00, 'Deposit', '2023-01-20 11:30:00'),
(1006, 105, -50.00, 'Withdrawal', '2023-01-22 13:15:00'),
(1007, 101, 750.00, 'Deposit', '2023-01-25 09:45:00'),
(1008, 102, -250.00, 'Withdrawal', '2023-01-28 15:30:00');

-- Insert sample data into Loans
INSERT INTO Loans VALUES
(2001, 1, 10000.00, 5.5, '2022-06-15', '2025-06-15', 'Active'),
(2002, 2, 15000.00, 6.0, '2022-08-20', '2026-08-20', 'Active'),
(2003, 4, 5000.00, 4.5, '2023-01-10', '2024-01-10', 'Active'),
(2004, 3, 8000.00, 5.0, '2021-10-15', '2023-10-15', 'Closed'),
(2005, 1, 12000.00, 5.8, '2023-01-05', '2026-01-05', 'Active');



-- 1. Required JOIN Queries

-- INNER JOIN: Show customers with their account details
SELECT c.CustomerID, c.FirstName, c.LastName, a.AccountID, a.AccountType, a.Balance
FROM Customers c
INNER JOIN Accounts a ON c.CustomerID = a.CustomerID;

-- LEFT JOIN: Show all customers and their accounts (including customers without accounts)
SELECT c.CustomerID, c.FirstName, c.LastName, a.AccountID, a.AccountType, a.Balance
FROM Customers c
LEFT JOIN Accounts a ON c.CustomerID = a.CustomerID;

-- 2. UPDATE and DELETE Queries

-- UPDATE: Increase balance for all savings accounts by 1% interest
UPDATE Accounts
SET Balance = Balance * 1.01
WHERE AccountType = 'Savings' AND AccountID > 0;
SET SQL_SAFE_UPDATES = 0;

-- DELETE: Remove inactive customers
-- First delete transactions for inactive customers' accounts
DELETE FROM Transactions
WHERE AccountID IN (
    SELECT AccountID FROM Accounts 
    WHERE CustomerID IN (
        SELECT CustomerID FROM Customers WHERE Status = 'Inactive'
    )
);

-- Then delete accounts for inactive customers
DELETE FROM Accounts
WHERE CustomerID IN (
    SELECT CustomerID FROM Customers WHERE Status = 'Inactive'
);

-- Then delete loans for inactive customers
DELETE FROM Loans
WHERE CustomerID IN (
    SELECT CustomerID FROM Customers WHERE Status = 'Inactive'
);

-- Finally delete the inactive customers
DELETE FROM Customers
WHERE Status = 'Inactive';

-- 3. Aggregation Queries
-- COUNT with GROUP BY and HAVING: Count transactions per account, showing only accounts with more than 1 transaction

-- AVG with GROUP BY: Average transaction amount by transaction type


-- SUM with GROUP BY: Total loan amount per customer
SELECT c.CustomerID, c.FirstName, c.LastName, SUM(l.Amount) AS TotalLoans
FROM Customers c
JOIN Loans l ON c.CustomerID = l.CustomerID
GROUP BY c.CustomerID, c.FirstName, c.LastName;